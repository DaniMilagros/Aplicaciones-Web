﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

public class EstudiosController : Controller
{
    public IActionResult Estudios()
    {
        return View();
    }
}