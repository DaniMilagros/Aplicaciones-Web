﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

public class NacimientoController : Controller
{
    public IActionResult Nacimiento()
    {
        return View();
    }
}