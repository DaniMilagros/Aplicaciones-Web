﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

public class DatosController : Controller
{
    public IActionResult DatosPersonales()
    {
        return View();
    }
}