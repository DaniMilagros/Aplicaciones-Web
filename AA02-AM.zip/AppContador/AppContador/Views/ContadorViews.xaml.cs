using AppContador.ViewModels;

namespace AppContador.Views;

public partial class ContadorViews : ContentPage
{
	public ContadorViews()
	{
		InitializeComponent();
		BindingContext = new ContadorViewModel();
	}
}