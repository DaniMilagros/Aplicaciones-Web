﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppContador.ViewModels
{
    public partial class ContadorViewModel : ObservableObject
    {
        [ObservableProperty]
        private int _contador;

        [RelayCommand]
        private void Incrementar()

        {
            Contador++;
        }
        [RelayCommand]
        private void Disminuir()
        { 
            Contador--;

        }

    }
}
